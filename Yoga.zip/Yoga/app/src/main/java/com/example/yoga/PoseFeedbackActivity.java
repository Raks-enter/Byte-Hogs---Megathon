package com.example.yoga;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yoga.R;

import java.io.IOException;

public class PoseFeedbackActivity extends AppCompatActivity {
    private VideoView videoViewSelected;
    private VideoView videoViewGolden;
    private com.example.yogaapp.LiteHRNetModel liteHRNetModel;

    // Custom View to draw circles
    private OverlayView overlayView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pose_feedback);

        videoViewSelected = findViewById(R.id.videoViewSelected);
        videoViewGolden = findViewById(R.id.videoViewGolden);
        Button buttonCompare = findViewById(R.id.buttonCompare);
        overlayView = new OverlayView(this);

        // Set the overlay view on top of the VideoViews
        RelativeLayout overlay = findViewById(R.id.overlay);
        overlay.addView(overlayView);

        // Load the LiteHRNet model
        try {
            liteHRNetModel = new com.example.yogaapp.LiteHRNetModel(this, "litehrnet.tflite");
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to load model", Toast.LENGTH_SHORT).show();
        }

        // Set up the VideoViews
        setupVideoViews();

        buttonCompare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comparePoses();
            }
        });
    }

    private void setupVideoViews() {
        // Load videos (replace with actual URIs)
        Uri selectedVideoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.selected_video);
        Uri goldenVideoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.golden_video);

        videoViewSelected.setVideoURI(selectedVideoUri);
        videoViewGolden.setVideoURI(goldenVideoUri);

        videoViewSelected.start();
        videoViewGolden.start();
    }

    private void comparePoses() {
        // Here you should extract frames and run inference
        // Example of calling your model inference method
        // float[][][] inputPoseData = ... // Prepare input data from video frames
        // float[][][] outputPoseData = liteHRNetModel.doInference(inputPoseData);

        // For demo, we assume you got some mismatches
        // Draw red circles where mismatches occur
        drawMismatchCircles(new int[][]{{100, 150}, {200, 250}, {300, 350}});
    }

    private void drawMismatchCircles(int[][] positions) {
        overlayView.setPositions(positions);
        overlayView.invalidate(); // Redraw the overlay
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (liteHRNetModel != null) {
            liteHRNetModel.close();
        }
    }

    // Custom view class to handle drawing
    private class OverlayView extends View {
        private Paint paint = new Paint();
        private int[][] positions;

        public OverlayView(Context context) {
            super(context);
            paint.setColor(Color.RED);
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
        }

        public void setPositions(int[][] positions) {
            this.positions = positions;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (positions != null) {
                for (int[] pos : positions) {
                    canvas.drawCircle(pos[0], pos[1], 30, paint); // Draw circle at specified positions
                }
            }
        }
    }
}
