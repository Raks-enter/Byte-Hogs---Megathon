package com.example.yoga;

public class Interpreter {

    public void close() {
    }
}
