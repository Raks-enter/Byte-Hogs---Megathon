package com.example.yogaapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AsanasSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asanas_selection);

        // Code to display and handle the list of asanas goes here
    }
}
