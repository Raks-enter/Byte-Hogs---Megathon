package com.example.yoga;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yoga.R;

public class UserDetailsActivity extends AppCompatActivity {

    // Define EditText fields for user details
    private EditText ageEditText, heightEditText, weightEditText, genderEditText;
    private Button nextButton;

    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        // Initialize EditText fields and button
        ageEditText = findViewById(R.id.age);
        heightEditText = findViewById(R.id.height);
        weightEditText = findViewById(R.id.weight);
        genderEditText = findViewById(R.id.genderGroup);
        nextButton = findViewById(R.id.nextbutton);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Move to the Asanas selection activity
                Intent intent = new Intent(UserDetailsActivity.this, com.example.yogaapp.AsanasSelectionActivity.class);
                startActivity(intent);
            }
        });
    }
}
