package com.example.yoga;

public class File extends java.io.File {
    public File(String modelPath) {
        super();
    }
}
