package com.example.yoga;

public class Asana {
    // Fields for name, description, and image resource ID
    private String name;
    private String description;
    private int imageResId;

    // Constructor
    public Asana(String name, String description, int imageResId) {
        this.name = name;
        this.description = description;
        this.imageResId = imageResId;
    }

    // Getters for each field
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageResId() {
        return imageResId;
    }
}
